package Peliculas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JRadioButton;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;

public class GUIPeliculas extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	// Crear un arreglo de objetos Peliculas
    private Peliculas[] listaPeliculas = {
        new Peliculas("El hombre de Fuego", "Tony Scott", "Acción", 2004),
        new Peliculas("No se aceptan devoluciones", "Eugenio Derbez", "Comedia", 2013),
        new Peliculas("Los cronocrímenes", "Nacho Vigalondo", "Ciencia Ficción", 2007),
        new Peliculas("El secreto de sus ojos", "Juan José Campanella", "Suspenso", 2009),
        new Peliculas("El orfanato", "J.A. Bayona", "Terror", 2007)
    };
    // Crear un arreglo para las rutas de las imágenes
    private String[] imagenesPeliculas = {
    	    "/ImagenesPeli/Hombre en llamas.jpeg", 
    	    "/ImagenesPeli/No se aceptan devoluciones.jpeg",
    	    "/ImagenesPeli/Los cronocrimenes.jpeg",
    	    "/ImagenesPeli/El secreto de sus ojos.jpeg",
    	    "/ImagenesPeli/El orfanato.jpeg"
    };
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUIPeliculas frame = new GUIPeliculas();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GUIPeliculas() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 615, 613);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblPeliculas = new JLabel("Peliculas:");
		lblPeliculas.setFont(new Font("Stencil", Font.ITALIC, 20));
		lblPeliculas.setBounds(10, 11, 117, 26);
		contentPane.add(lblPeliculas);
		
		JComboBox comboPelicular = new JComboBox();
		comboPelicular.setFont(new Font("Stencil", Font.ITALIC, 20));
		comboPelicular.setModel(new DefaultComboBoxModel(new String[] {"", "El hombre de Fuego", "No se aceptan devoluciones", "Los cronocrímenes", "El secreto de sus ojos", "El orfanato"}));
		comboPelicular.setBounds(130, 12, 372, 26);
		contentPane.add(comboPelicular);
		
		JButton btnImagenPeli = new JButton("ImagenPelicula");
		btnImagenPeli.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnImagenPeli.setBounds(10, 58, 250, 238);
		contentPane.add(btnImagenPeli);
		
		JButton btnCalificacion = new JButton("Calificacion");
		btnCalificacion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnCalificacion.setFont(new Font("Stencil", Font.ITALIC, 20));
		btnCalificacion.setBounds(282, 58, 299, 36);
		contentPane.add(btnCalificacion);
		
		JTextArea textPelicula = new JTextArea();
		textPelicula.setFont(new Font("Stencil", Font.ITALIC, 15));
		textPelicula.setBounds(10, 307, 250, 85);
		contentPane.add(textPelicula);
		
		JTextArea textReseña = new JTextArea();
		textReseña.setBounds(282, 105, 299, 135);
		contentPane.add(textReseña);
		
		// Añadir ActionListener al comboBox para mostrar los datos de la película seleccionada
        comboPelicular.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	int selectedIndex = comboPelicular.getSelectedIndex() - 1; // Restamos 1 porque el primer elemento es vacío
                if (selectedIndex >= 0) {
                    Peliculas peliculaSeleccionada = listaPeliculas[selectedIndex];
                    textPelicula.setText("Título: " + peliculaSeleccionada.getTitulo() + "\n" +
                                         "Director: " + peliculaSeleccionada.getDirector() + "\n" +
                                         "Género: " + peliculaSeleccionada.getGenero() + "\n" +
                                         "Año: " + peliculaSeleccionada.getAño());
                 // Cargar la imagen de la película seleccionada
                    ImageIcon imagen = new ImageIcon(getClass().getResource(imagenesPeliculas[selectedIndex]));
                    btnImagenPeli.setIcon(imagen); // Asignar la imagen al botón
                } else {
                    textPelicula.setText("");
                    btnImagenPeli.setIcon(null); // Limpiar la imagen si no hay selección
                }
            }
        });
		
		JButton btnEnviar = new JButton("Enviar Reseña");
		btnEnviar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 String reseñaTexto = textReseña.getText();
	                textReseña.setText("Reseña enviada:\n" + reseñaTexto);
			}
		});
		btnEnviar.setFont(new Font("Stencil", Font.ITALIC, 14));
		btnEnviar.setBounds(438, 251, 143, 36);
		contentPane.add(btnEnviar);
			
		JButton btnEditar = new JButton("Editar Reseña");
		btnEditar.setFont(new Font("Stencil", Font.ITALIC, 14));
		btnEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnEditar.setBounds(282, 251, 137, 36);
		contentPane.add(btnEditar);
		
		JButton btnEliminar = new JButton("Eliminar Reseña");
		btnEliminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnEliminar.setFont(new Font("Stencil", Font.ITALIC, 14));
		btnEliminar.setBounds(337, 298, 165, 36);
		contentPane.add(btnEliminar);
	}
}
